#!/usr/bin/env python
# coding: utf-8

# In[1]:


def addition(a,b):
    return a+b
def subtraction(a,b):
    return a-b
def multiplication(a,b):
    return a*b
def division(a,b):
    return a/b



# In[ ]:




